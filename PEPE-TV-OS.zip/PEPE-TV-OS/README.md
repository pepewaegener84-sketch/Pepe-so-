# PEPE TV OS

Eigenständige Startseiten-App (Launcher-Oberfläche) für Amazon Fire TV mit Fire OS 7 (Android 9 / API 28).
Kotlin, Android Views, RecyclerView. Keine Google Play Services, keine APIs, keine Konten.

## Was die App kann (implementiert)
- Installierte, startbare Apps dynamisch erkennen (Leanback und normale Launcher-Apps) und starten
- Netflix, YouTube, Prime Video, Disney+ stehen vorn, aber nur, wenn wirklich installiert
- Zuletzt verwendet (nur Apps, die über PEPE TV OS gestartet wurden), Favoriten (hinzufügen, entfernen, verschieben)
- Uhrzeit und Datum, 24h/12h
- Einstellungen: Hintergrund (4 eingebaute Verläufe), Akzentfarbe, Uhrzeitformat, Fokus-Animation, Link zu den Fire-TV-Systemeinstellungen
- Komplette Bedienung per Fernbedienung, Fokus immer sichtbar (Rahmen + leichte Vergrößerung)

## Bewusst nicht enthalten
- Übernahme der Home-Taste. Fire OS erlaubt das nicht offiziell; ein solches Modul wäre geräteabhängig und ist hier nicht gebaut.
- Eigene Hintergrundbilder aus Dateien (Fire OS hat keinen verlässlichen Dateiwähler). Es gibt eingebaute Hintergründe.
- Zuletzt-verwendet-Liste anderer Apps (dafür wäre Nutzungszugriff nötig).
- Der Code wurde nicht auf einem echten Gerät getestet. Der erste GitHub-Build und der Fernbedienungstest sind dein Abnahmetest.

## Projektstruktur
```
PEPE-TV-OS/
├─ settings.gradle / build.gradle / gradle.properties
├─ .github/workflows/build.yml          GitHub-Actions-Build
└─ app/
   ├─ build.gradle                      minSdk 28, targetSdk 28
   └─ src/main/
      ├─ AndroidManifest.xml            Leanback-Launcher, Banner
      ├─ java/tv/pepe/os/
      │   ├─ MainActivity.kt            Startseite, App-Menü, Menü-Taste
      │   ├─ SettingsActivity.kt        Einstellungen
      │   ├─ AppAdapter.kt              Kacheln, Fokus-Animation
      │   ├─ AppRepository.kt           installierte Apps ermitteln
      │   ├─ AppEntry.kt
      │   ├─ Prefs.kt                   Favoriten, Zuletzt, Einstellungen
      │   └─ Look.kt                    Farben, Hintergründe
      └─ res/  layout, drawable (Logo, Banner, Icons), values
```

## 1. APK mit GitHub Actions bauen (iPad)
1. Auf github.com ein neues **öffentliches** Repository anlegen (öffentlich, damit die Downloader-App die APK laden kann).
2. Projektdateien hochladen, mit Ordnerstruktur:
   - Variante A: ZIP in der Dateien-App entpacken, auf github.com "Add file → Upload files" und den Inhalt des Ordners PEPE-TV-OS (inkl. `.github`) per Drag-and-drop aus der Dateien-App in Split View ziehen.
   - Variante B: Im Repo "Code → Codespaces → Create codespace", ZIP in den Explorer ziehen, im Terminal `unzip PEPE-TV-OS.zip`, Inhalt in den Repo-Stamm verschieben, dann `git add -A && git commit -m "PEPE TV OS" && git push`.
3. Reiter **Actions**: Der Workflow "Build PEPE TV OS" startet bei jedem Push auf `main` (oder manuell über "Run workflow").
4. Nach ca. 3 bis 5 Minuten: APK als Artifact im Lauf, außerdem unter **Releases → "PEPE TV OS - letzter Build"**.
   Direktlink: `https://github.com/DEIN-NAME/DEIN-REPO/releases/download/latest/PEPE-TV-OS-debug.apk`

## 2. Installation auf Fire TV
Auf dem Fire TV: Einstellungen → Mein Fire TV → Entwickleroptionen → **Apps unbekannter Herkunft** erlauben (bzw. für die Downloader-App).
- **Downloader-App** (Amazon Appstore, "Downloader" von AFTVnews) installieren, den Direktlink oben eingeben, herunterladen, installieren.
- Alternativ mit PC/Mac: Entwickleroptionen → ADB-Debugging an, dann `adb connect FIRE-TV-IP` und `adb install -r PEPE-TV-OS-debug.apk`.
- Start: Apps & Spiele → Alle anzeigen → PEPE TV OS. Die Home-Taste führt weiterhin zur Amazon-Oberfläche.

## 3. Fernbedienung testen
- Pfeiltasten: Fokus wandert zwischen Kacheln und Zeilen, der Rahmen ist immer sichtbar
- OK: App starten bzw. Eintrag ändern
- OK gedrückt halten oder Menü-Taste (drei Striche) auf einer Kachel: App-Menü (Starten, Favorit, verschieben, App-Info)
- Menü-Taste ohne Kachel im Fokus: Einstellungen
- Zurück: auf der Startseite zurück nach oben, in den Einstellungen zurück zur Startseite
- Checkliste: Favorit hinzufügen, in Favoriten verschieben, entfernen; App starten und zurückkehren (Zuletzt-Zeile aktualisiert); Hintergrund und Akzentfarbe wechseln

## 4. Fehlerbehebung (Fire OS 7)
- **GitHub-Build rot**: im Actions-Log nach der ersten Fehlerzeile suchen. Häufig: Ordnerstruktur beim Upload verloren (`app/build.gradle` muss im Unterordner `app` liegen, `.github/workflows/build.yml` im Stamm).
- **Kein Release / Downloader findet nichts**: Repo muss öffentlich sein; Workflow braucht Schreibrechte (Settings → Actions → General → Workflow permissions → Read and write).
- **"App nicht installiert"**: eine ältere Version mit anderer Signatur deinstallieren (Debug-Builds von verschiedenen Runnern können unterschiedlich signiert sein), dann neu installieren.
- **Installation blockiert**: "Apps unbekannter Herkunft" für die Downloader-App aktivieren.
- **App fehlt unter Apps**: Fire OS zeigt neue Apps ganz unten in "Alle anzeigen"; ggf. Fire TV neu starten.
- **Kachel einer App fehlt**: App besitzt keinen startbaren Eintrag oder ist nicht installiert (Paketnamen von Netflix/YouTube/Prime können je Gerät abweichen, die Liste ist dynamisch).
- **App startet nicht**: Meldung erscheint; App neu installieren oder Fire TV neu starten.
- **targetSdk 28**: nur für Sideloading gedacht (für den Play Store nicht zulässig). Später in `app/build.gradle` anheben.
